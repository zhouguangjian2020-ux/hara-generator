# S/E/C 评定参考（SAE J2980）

> 本文件供 HAZOP → HARA 转换流程中的 Agent 使用。
> 内容来源：SAE J2980《Hazard Analysis and Risk Assessment — Examples》。
> 用途：为严重度（S）、暴露概率（E）、可控性（C）三个因子的等级评定提供**基于速度/碰撞数据的量化判定方法与示例**，辅助 Agent 在 HARA 分析中对 S/E/C 做出合理判定。
> 注意：J2980 与 ISO 26262 的 S/E/C 等级定义一致，但 J2980 提供了更多**基于全球事故数据库的量化速度阈值**，严重度评定以碰撞速度变化量（ΔV）为核心依据。

---

## 1. 严重度等级（Severity, S）

### 1.1 速度参考判定（Severity Reference）

根据车辆行驶速度选择参考速度类型，再结合碰撞表判定严重度：

| 车速范围（Speed） | 参考速度（Reference speed） | 严重度（S） |
|------------------|---------------------------|------------|
| 0 ~ 80 kph | 相对速度（Relative speed） | 参照碰撞表（Refer to Collision Table） |
| 80 ~ 100 kph | 两者兼顾（Both，相对速度与绝对速度） | Max{碰撞表结果, S2} |
| > 100 kph | 绝对速度（Absolute speed） | S3 |

> **判定逻辑**：
> - 车速 ≤ 80 kph 时，以相对碰撞速度（ΔV）查碰撞表。
> - 车速 80~100 kph 时，同时考虑相对速度和绝对速度，取碰撞表结果与 S2 中的**较高者**。
> - 车速 > 100 kph 时，直接定为 S3。

### 1.2 与车辆或护栏碰撞（Collision with vehicle or guardrail）

以碰撞速度变化量 ΔV（单位：kph）判定：

| 碰撞类型（Class） | S0 | S1 | S2 | S3 |
|------------------|----|----|----|-----|
| 正面碰撞（Front Collision） | ΔV < 10 | 10 < ΔV < 30 | 30 < ΔV < 60 | ΔV > 60 |
| 追尾碰撞（Rear Collision） | ΔV < 10 | 10 < ΔV < 30 | 30 < ΔV < 60 | ΔV > 60 |
| 侧面碰撞（Side Collision） | ΔV < 3 | 3 < ΔV < 15 | 15 < ΔV < 30 | ΔV > 30 |

### 1.3 与行人或两轮/三轮车碰撞（Collision with pedestrian or two/three-wheeler）

以碰撞速度变化量 ΔV（单位：kph）判定：

| 碰撞类型（Class） | S0 | S1 | S2 | S3 |
|------------------|----|----|----|-----|
| 碰撞（Collision） | ΔV < 3 kph | 3 < ΔV < 10 | 10 < ΔV < 25 | ΔV > 25 |

### 1.4 全球事故数据库速度范围（Table B1）

> Table B1 — Minimum and maximum speed ranges (delta v) from various analyses of global accident databases
> （基于全球事故数据库多项分析的最小和最大速度变化量范围）

下表给出了各碰撞类型下不同严重度等级对应的 ΔV 范围。由于不同事故数据库的分析结果存在差异，阈值以**区间**形式给出（如 4-10 kph 表示不同研究得出的阈值在 4 至 10 kph 之间）。

| 碰撞类型（Collision Type） | 范围（Range For） | S0 | S1 | S2 | S3 |
|---------------------------|------------------|----|----|----|-----|
| 正面（Front） | 最小速度（Minimum speed） | — | > 4-10 kph 且 | > 20-50 kph 且 | > 40-65 kph |
| 正面（Front） | 最大速度（Maximum speed） | < 4-10 kph* | < 20-50 kph | ≤ 40-65 kph | — |
| 追尾（Back） | 最小速度（Minimum speed） | — | > 4-10 kph 且 | > 20-50 kph 且 | > 40-60 kph |
| 追尾（Back） | 最大速度（Maximum speed） | < 4-10 kph* | < 20-50 kph | ≤ 40-60 kph | — |
| 侧面（Side） | 最小速度（Minimum speed） | — | > 2-10 kph 且 | ≥ 8-30 kph 且 | > 16-40 kph |
| 侧面（Side） | 最大速度（Maximum speed） | < 2-3 kph* | < 8-30 kph | < 16-40 kph | — |

> **读法说明**：以正面碰撞 S1 为例，最小速度 > 4-10 kph 且最大速度 < 20-50 kph，即 ΔV 落在约 4~50 kph 区间内（不同数据库的具体阈值有差异）。
>
> **\* 注**：S0 列的星号（< 4-10 kph\*、< 2-3 kph\*）表示低于该速度上限时归入 S0（无伤害），原表未提供对应脚注文字。

---

## 2. 暴露概率等级（Exposure, E）

### 2.1 E 等级量化界限（Table D4）

> Table D4 — Calculated limits for E-parameter classes
> （E 参数等级的计算界限）

J2980 将 ISO 26262 的定性描述转换为**每年运行小时数**和**每年驾驶循环次数**的量化界限：

| | E1 | E2 | E3 | E4 |
|---|----|----|----|-----|
| ISO 26262 描述（持续时间）（ISO 26262 description, duration） | 未规定（极低概率）Not specified (very low probability) | < 平均运行时间的 1%（<1% of average operating time） | 平均运行时间的 1%~10%（1 to 10% of average operating time） | > 平均运行时间的 10%（>10% of average operating time） |
| 基于假定运行时间 [h/yr]（Based on assumed operation time） | < 0.4 h/yr | 4 h/yr < x ≤ 4 h/yr ⚠️ | 4 h/yr < x ≤ 40 h/yr | > 40 h/yr |
| ISO 26262 描述（频率）（ISO 26262 description, frequency） | 少于每年一次（Less often than once a year） | 每年数次（A few times a year） | 每月一次或更频繁（Once a month or more often） | 几乎每次驾驶（During almost every drive） |
| 基于假定驾驶循环次数 [次/yr]（Based on assumed number of drive cycles） | < 1 次/yr | 1 次/yr < x < 10 次/yr | 10 次/yr < x < 100 次/yr | > 100 次/yr |

> ⚠️ **原文勘误提示**：E2 持续时间的原文为 "4h/yr < x ≤ 4 h/yr"，数学上为空区间，应为 **"0.4 h/yr < x ≤ 4 h/yr"** 之误（与 E1 上限 0.4 h/yr 和 E3 下限 4 h/yr 衔接）。Agent 使用时按 0.4~4 h/yr 理解。

### 2.2 量化换算依据

- 假定年平均运行时间约为 **400 小时**（基于典型驾驶场景估算）：
  - E2 上限 1% × 400 h = 4 h/yr
  - E3 上限 10% × 400 h = 40 h/yr
  - E1 上限 0.1% × 400 h = 0.4 h/yr
- 假定年平均驾驶循环约为 **1000 次**：
  - E2 频率"每年数次"≈ 1~10 次/yr
  - E3 频率"每月一次或更频繁"≈ 10~100 次/yr
  - E4 频率"几乎每次驾驶"≈ >100 次/yr

---

## 3. 可控性等级（Controllability, C）

### 3.1 J2980 的可控性参考

J2980 本 sheet **未提供可控性的具体参考示例**（原文："No specific reference for controllability"）。

> **Agent 指引**：可控性（C）的评定请参照 ISO 26262 的 S/E/C 评定参考（见 `sec-evaluation-reference-iso26262.md` 第 3 节），其中包含 C0-C3 的定义、量化阈值（>99% / 90%-99% / <90%）及 8 个危险事件示例。

---

## 4. Agent 评定指引

### 4.1 S 评定流程（J2980 方法）

1. 确定车辆**当前行驶速度**：
   - ≤ 80 kph → 使用相对速度（ΔV）查第 1.2/1.3 节碰撞表。
   - 80~100 kph → 查碰撞表后与 S2 取较高者。
   - \> 100 kph → 直接 S3。
2. 根据碰撞对象选择对应表格：
   - 车辆/护栏 → 第 1.2 节（正面/追尾/侧面，ΔV 阈值不同）。
   - 行人/两轮三轮车 → 第 1.3 节。
3. 以碰撞速度变化量 ΔV 对照阈值确定 S0-S3。
4. 可参照第 1.4 节 Table B1 的全球事故数据库范围进行交叉验证。
5. 边界值处理：ΔV 恰好等于阈值时，按**就高不就低**原则取较高等级（保守评定）。

### 4.2 E 评定流程（J2980 方法）

1. 估算该运行场景的**年累计时间**（h/yr）或**年发生次数**（次/yr）。
2. 对照第 2.1 节 Table D4 量化界限：
   - 持续时间：<0.4 / 0.4~4 / 4~40 / >40 h/yr → E1/E2/E3/E4
   - 频率：<1 / 1~10 / 10~100 / >100 次/yr → E1/E2/E3/E4
3. 两个维度取**较高等级**（保守评定）。
4. 若无法精确量化，可参照 ISO 26262 的定性描述和示例场景评定（见 `sec-evaluation-reference-iso26262.md` 第 2 节）。

### 4.3 C 评定流程

J2980 未提供可控性参考，直接使用 ISO 26262 方法（见 `sec-evaluation-reference-iso26262.md` 第 3 节及第 4.3 节评定流程）。

### 4.4 综合注意事项

- J2980 的严重度评定以 **ΔV（碰撞速度变化量）** 为核心量化指标，比 ISO 26262 的定性示例更具可操作性。
- Table B1 的速度范围来自不同事故数据库，存在差异区间；实际评定时应结合具体碰撞构型选择合适的阈值。
- 车速 80~100 kph 时的 "Max{Table1, S2}" 规则体现了**绝对速度风险**的考量——即使相对碰撞速度较低，高速行驶本身也可能导致严重后果。
- S/E/C 确定后，使用 ASIL 判定表（见 `asil-determination-rules.md`）查表得出 ASIL 等级。
